const redisClient = require('../config/redis');
const getClientIp = require('../utils/getUserIp');

const ROUTES = { login: 10, admin: 15, signup: 5, reset: 8 };

const threatScoring = async (req, res, next) => {
  try {
    const ip = getClientIp(req);
    let score = parseInt(await redisClient.get(`score:${ip}`)) || 0;
    const route = req.originalUrl.toLowerCase();
    let delta = 0;

    for (const [k, pts] of Object.entries(ROUTES)) {
      if (route.includes(k)) delta += pts;
    }
    // Decay: clean requests slowly lower the score
    if (delta === 0 && score > 0) delta = -5;

    score = Math.max(0, score + delta);
    await redisClient.set(`score:${ip}`, score, 'EX', 600);
    req.threatScore = score;
    next();
  } catch { next(); }
};

module.exports = threatScoring;