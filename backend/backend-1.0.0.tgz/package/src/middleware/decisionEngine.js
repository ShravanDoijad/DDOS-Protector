const redisClient = require('../config/redis');
const getClientIp = require('../utils/getUserIp');
const { sendAlert } = require('../utils/alert');

const decisionEngine = async (req, res, next) => {
  try {
    const ip = getClientIp(req);
    let score = parseInt(req.threatScore) || 0;

    if (score > 60) {
      await redisClient.set(`blocked:${ip}`, '1', 'EX', 60 * 30);
      sendAlert({ ip, event: 'IP Blocked', severity: 'high', detail: `IP exceeded threat score threshold (${score} > 60). Blocked for 30 minutes.` });
      return res.status(403).json({ message: 'Blocked: high threat score.' });
    }
    if (score > 40) {
      await redisClient.set(`blocked:${ip}`, '1', 'EX', 60 * 5);
      sendAlert({ ip, event: 'Temporary Block', severity: 'medium', detail: `IP received temporary block due to high score (${score} > 40).` });
      return res.status(429).json({ message: 'Temporarily blocked.' });
    }
    if (score > 20) await new Promise(r => setTimeout(r, 1500));
    next();
  } catch { next(); }
};

module.exports = decisionEngine;