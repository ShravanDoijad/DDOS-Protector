const redisClient = require('../config/redis');
const getClientIp = require('../utils/getUserIp');

const LIMITS = {
  '/api/login':  [10,  60],   
  '/api/signup': [5,   60],
  '/api/reset':  [3,  300],
  '/api/upload': [20,  60],
  '/api/search': [60,  60],
  default:       [300, 60],
};

const getLimit = (p) => {
  for (const [r, l] of Object.entries(LIMITS))
    if (r !== 'default' && p.startsWith(r)) return l;
  return LIMITS.default;
};

const smartRateLimit = async (req, res, next) => {
  try {
    const ip = getClientIp(req);
    const [max, win] = getLimit(req.path);
    const key = `rl:${ip}:${req.path.split('/').slice(0, 3).join('/')}`;
    const n = parseInt(await redisClient.get(key)) || 0;
    if (n >= max) {
      res.set('Retry-After', win);
      return res.status(429).json({ message: 'Rate limit exceeded.', limit: max, retryAfter: win });
    }
    n === 0 ? await redisClient.set(key, 1, 'EX', win) : await redisClient.incr(key);
    res.set('X-RateLimit-Limit', max);
    res.set('X-RateLimit-Remaining', max - n - 1);
    next();
  } catch { next(); }
};

module.exports = smartRateLimit;